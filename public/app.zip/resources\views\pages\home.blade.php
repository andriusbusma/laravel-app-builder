@extends('layouts.default')
@section('content')
<div class="row">
  <div class="col-6 mb-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Categories</h5>
        <a href="{{route('categories.index')}}" class="btn btn-primary">View all</a>
        <a href="{{route('categories.create')}}" class="btn btn-success">New Category</a>
      </div>
    </div>
  </div>
  <div class="col-6 mb-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Products</h5>
        <a href="{{route('products.index')}}" class="btn btn-primary">View all</a>
        <a href="{{route('products.create')}}" class="btn btn-success">New Product</a>
      </div>
    </div>
  </div>
  <div class="col-6 mb-4">
    <div class="card">
      <div class="card-body">
        <h5 class="card-title">Suppliers</h5>
        <a href="{{route('suppliers.index')}}" class="btn btn-primary">View all</a>
        <a href="{{route('suppliers.create')}}" class="btn btn-success">New Supplier</a>
      </div>
    </div>
  </div>
</div>
@stop

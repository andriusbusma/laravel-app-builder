<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class ProductController extends Controller
{
  
    public function index()
    {
        return view('pages.products.index', ['products' => \App\Models\Product::query()->orderBy('id', 'DESC')->paginate(20)]);
    }

    public function create()
    {
        return view('pages.products.create')->with('suppliers',\App\Models\Supplier::all())->with('categories',\App\Models\Category::all());
    }

    public function store(Request $request)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $product = \App\Models\Product::create($data);

        foreach ($relations as $key => $value) {
          $product->{$key}()->sync($value);
        }
        return redirect()->route('products.index');
    }

    public function edit(\App\Models\Product $product)
    {
        return view('pages.products.edit', ['product' => $product])->with('suppliers',\App\Models\Supplier::all())->with('categories',\App\Models\Category::all());
    }

    public function update(Request $request, \App\Models\Product $product)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $product ->update($data);

        foreach ($relations as $key => $value) {
          $product->{$key}()->sync($value);
        }

        return redirect()->route('products.index');
    }

    public function destroy(\App\Models\Product $product)
    {
        $product ->delete();
        return redirect()->route('products.index');
    }


}

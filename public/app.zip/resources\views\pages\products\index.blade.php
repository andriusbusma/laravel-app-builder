@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">Products</span>
            <div>
            <button type="button" class="btn btn-success btn-sm" onclick="tableToCSV()">
            Export CSV
            </button>
            <a href="{{route('products.create')}}"
                    class="btn btn-primary btn-sm">New Product</a></div>
        </div>
        <div class="card-body table-responsive">
            <table class="table" id="table">
                <thead>
                    <tr>
                        <th class="text_start">ID</th>
                        <th class="text-center">Name</th>
                        <th class="text-center">Active</th>
                        <th class="text-center">Quantity</th>
                        <th class="text-center">Decimal</th>
                        <th class="text-center">Supplier</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($products as $product)
                        <tr>
                          <td class="text_start" >{{$product -> id}}</td>
                          <td class="text-center" >{{$product -> name}}</td>
                          <td class="text-center" >@if($product -> active)<span class="badge badge-success">Yes</span>@else<span class="badge badge-danger">No</span>@endif</td>
                          <td class="text-center" >{{$product -> quantity}}</td>
                          <td class="text-center" >{{$product -> decimal}}</td>
                          <td class="text-center" >@if($product -> supplier) {{$product -> supplier -> name}}@endif</td>
                          <td class="text-end" style="width:15%">
                          <a href="{{route('products.edit', ['product' => $product])}}" class="btn btn-primary btn-sm">Edit</a>
                          <form method="POST" action="{{route('products.destroy', ['product' => $product])}}" class="d-inline">
                              @csrf
                              @method('DELETE')
                              <button href="{{route('products.destroy', ['product' => $product])}}" class="btn btn-danger btn-sm">Delete</button>
                          </form></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            {{ $products ->links() }}
        </div>
    </div>
@stop
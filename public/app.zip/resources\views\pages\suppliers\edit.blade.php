@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">Edit Supplier</span>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('suppliers.update', ['supplier' => $supplier])}}">
            @method('PUT')
            @csrf
            <div class="row">
<div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="text" id="name" class="form-control" name="name" @if($supplier -> name)value="{{ $supplier -> name}}"@endif required/>
                        <label class="form-label" for="name">Name</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <textarea class="form-control" id="address" rows="4" name="address" > @if($supplier -> address){{ $supplier -> address}}@endif</textarea>
                        <label class="form-label" for="address">Address</label>
                    </div>
                </div>
                            </div>    
            <button type="submit" class="btn btn-primary">Update</button>
        </div>
    </div>
@stop

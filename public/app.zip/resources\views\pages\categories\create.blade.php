@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">New Category</span>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('categories.store')}}">
            @csrf
            <div class="row">
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="text" id="name" class="form-control" name="name" required/>
                        <label class="form-label" for="name">Name</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <textarea class="form-control" id="description" rows="4" name="description" ></textarea>
                        <label class="form-label" for="description">Description</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    @foreach ($products as $product)
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="{{ $product ->id}}" id="products_{{ $product ->id }}" name="products[]"/>
                        <label class="form-check-label" for="products_{{ $product ->id }}">{{ $product ->name}}</label>
                    </div>
                    @endforeach
                </div>
                            </div>    
            <button type="submit" class="btn btn-primary">Create</button>
        </div>
    </div>
@stop

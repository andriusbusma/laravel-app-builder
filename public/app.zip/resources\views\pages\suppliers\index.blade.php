@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">Suppliers</span>
            <div>
            <button type="button" class="btn btn-success btn-sm" onclick="tableToCSV()">
            Export CSV
            </button>
            <a href="{{route('suppliers.create')}}"
                    class="btn btn-primary btn-sm">New Supplier</a></div>
        </div>
        <div class="card-body table-responsive">
            <table class="table" id="table">
                <thead>
                    <tr>
                        <th class="text_start">ID</th>
                        <th class="text-center">Name</th>
                        <th class="text-end">Actions</th>
                    </tr>
                </thead>
                <tbody>
                    @foreach ($suppliers as $supplier)
                        <tr>
                          <td class="text_start" >{{$supplier -> id}}</td>
                          <td class="text-center" >{{$supplier -> name}}</td>
                          <td class="text-end" style="width:15%">
                          <a href="{{route('suppliers.edit', ['supplier' => $supplier])}}" class="btn btn-primary btn-sm">Edit</a>
                          <form method="POST" action="{{route('suppliers.destroy', ['supplier' => $supplier])}}" class="d-inline">
                              @csrf
                              @method('DELETE')
                              <button href="{{route('suppliers.destroy', ['supplier' => $supplier])}}" class="btn btn-danger btn-sm">Delete</button>
                          </form></td>
                        </tr>
                    @endforeach
                </tbody>
            </table>
            {{ $suppliers ->links() }}
        </div>
    </div>
@stop
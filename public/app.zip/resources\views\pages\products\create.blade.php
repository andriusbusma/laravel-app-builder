@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">New Product</span>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('products.store')}}">
            @csrf
            <div class="row">
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="text" id="name" class="form-control" name="name" required/>
                        <label class="form-label" for="name">Name</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-check form-switch">
                        <input type="hidden" name="active" value="0"> 
                        <input class="form-check-input" type="checkbox" role="switch" id="active" name="active" value="1"/>
                        <label class="form-label" for="active">Active</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="number" id="quantity" class="form-control" name="quantity" step="1" required/>
                        <label class="form-label" for="quantity">Quantity</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="number" id="decimal" class="form-control" name="decimal" step="any" required/>
                        <label class="form-label" for="decimal">Decimal</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <textarea class="form-control" id="description" rows="4" name="description" ></textarea>
                        <label class="form-label" for="description">Description</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <select class="form-select" name="supplier_id">
                    @foreach ($suppliers as $supplier)
                    <option value="{{ $supplier ->id}}">{{ $supplier ->name}}</option>
                        
                    @endforeach
                    </select>
                </div>
                <div class="col-6 mb-4">
                    @foreach ($categories as $category)
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" value="{{ $category ->id}}" id="categories_{{ $category ->id }}" name="categories[]"/>
                        <label class="form-check-label" for="categories_{{ $category ->id }}">{{ $category ->name}}</label>
                    </div>
                    @endforeach
                </div>
                            </div>    
            <button type="submit" class="btn btn-primary">Create</button>
        </div>
    </div>
@stop

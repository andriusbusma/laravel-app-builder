<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class CategoryController extends Controller
{
  
    public function index()
    {
        return view('pages.categories.index', ['categories' => \App\Models\Category::query()->orderBy('id', 'DESC')->paginate(20)]);
    }

    public function create()
    {
        return view('pages.categories.create')->with('products',\App\Models\Product::all());
    }

    public function store(Request $request)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $category = \App\Models\Category::create($data);

        foreach ($relations as $key => $value) {
          $category->{$key}()->sync($value);
        }
        return redirect()->route('categories.index');
    }

    public function edit(\App\Models\Category $category)
    {
        return view('pages.categories.edit', ['category' => $category])->with('products',\App\Models\Product::all());
    }

    public function update(Request $request, \App\Models\Category $category)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $category ->update($data);

        foreach ($relations as $key => $value) {
          $category->{$key}()->sync($value);
        }

        return redirect()->route('categories.index');
    }

    public function destroy(\App\Models\Category $category)
    {
        $category ->delete();
        return redirect()->route('categories.index');
    }


}

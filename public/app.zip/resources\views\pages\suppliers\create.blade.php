@extends('layouts.default')
@section('content')
    <div class="card">
        <div class="card-header d-flex justify-content-between align-items-center">
            <span class="fw-bold">New Supplier</span>
        </div>
        <div class="card-body">
            <form method="POST" action="{{route('suppliers.store')}}">
            @csrf
            <div class="row">
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <input type="text" id="name" class="form-control" name="name" required/>
                        <label class="form-label" for="name">Name</label>
                    </div>
                </div>
                <div class="col-6 mb-4">
                    <div class="form-outline">
                        <textarea class="form-control" id="address" rows="4" name="address" ></textarea>
                        <label class="form-label" for="address">Address</label>
                    </div>
                </div>
                            </div>    
            <button type="submit" class="btn btn-primary">Create</button>
        </div>
    </div>
@stop

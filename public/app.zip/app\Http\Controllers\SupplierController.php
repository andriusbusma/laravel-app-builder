<?php
namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SupplierController extends Controller
{
  
    public function index()
    {
        return view('pages.suppliers.index', ['suppliers' => \App\Models\Supplier::query()->orderBy('id', 'DESC')->paginate(20)]);
    }

    public function create()
    {
        return view('pages.suppliers.create');
    }

    public function store(Request $request)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $supplier = \App\Models\Supplier::create($data);

        foreach ($relations as $key => $value) {
          $supplier->{$key}()->sync($value);
        }
        return redirect()->route('suppliers.index');
    }

    public function edit(\App\Models\Supplier $supplier)
    {
        return view('pages.suppliers.edit', ['supplier' => $supplier]);
    }

    public function update(Request $request, \App\Models\Supplier $supplier)
    {
        $data = $request->except(['_method', '_token']);

        $relations = [];

        foreach ($data as $key => $value) {
            if(is_array($value)){
                unset($data[$key]);
                $relations[$key] = $value;
            }
        }

        $supplier ->update($data);

        foreach ($relations as $key => $value) {
          $supplier->{$key}()->sync($value);
        }

        return redirect()->route('suppliers.index');
    }

    public function destroy(\App\Models\Supplier $supplier)
    {
        $supplier ->delete();
        return redirect()->route('suppliers.index');
    }


}
